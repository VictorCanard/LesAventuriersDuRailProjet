package ch.epfl.tchu.gui;

class GuiUtils {
    static final int PORT = 5108;

    static final String COLORS = "colors.css";
}
